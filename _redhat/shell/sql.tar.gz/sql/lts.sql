-- MySQL dump 10.13  Distrib 5.7.22, for Linux (x86_64)
--
-- Host: localhost    Database: lts
-- ------------------------------------------------------
-- Server version	5.7.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `lts_admin_job_client_monitor_data`
--

DROP TABLE IF EXISTS `lts_admin_job_client_monitor_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_admin_job_client_monitor_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_created` bigint(20) DEFAULT NULL,
  `node_group` varchar(64) DEFAULT NULL,
  `identity` varchar(64) DEFAULT NULL,
  `submit_success_num` bigint(20) DEFAULT NULL,
  `submit_failed_num` bigint(11) DEFAULT NULL,
  `fail_store_num` bigint(20) DEFAULT NULL,
  `submit_fail_store_num` bigint(20) DEFAULT NULL,
  `handle_feedback_num` bigint(20) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_identity` (`identity`),
  KEY `idx_node_group` (`node_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_admin_job_tracker_monitor_data`
--

DROP TABLE IF EXISTS `lts_admin_job_tracker_monitor_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_admin_job_tracker_monitor_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_created` bigint(20) DEFAULT NULL,
  `identity` varchar(64) DEFAULT NULL,
  `receive_job_num` bigint(20) DEFAULT NULL,
  `push_job_num` bigint(20) DEFAULT NULL,
  `exe_success_num` bigint(20) DEFAULT NULL,
  `exe_failed_num` bigint(11) DEFAULT NULL,
  `exe_later_num` bigint(20) DEFAULT NULL,
  `exe_exception_num` bigint(20) DEFAULT NULL,
  `fix_executing_job_num` bigint(20) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_identity` (`identity`)
) ENGINE=InnoDB AUTO_INCREMENT=10346 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_admin_jvm_gc`
--

DROP TABLE IF EXISTS `lts_admin_jvm_gc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_admin_jvm_gc` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_created` bigint(20) DEFAULT NULL,
  `identity` varchar(64) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  `node_type` varchar(32) DEFAULT NULL,
  `node_group` varchar(64) DEFAULT NULL,
  `young_gc_collection_count` bigint(20) DEFAULT NULL,
  `young_gc_collection_time` bigint(20) DEFAULT NULL,
  `full_gc_collection_count` bigint(20) DEFAULT NULL,
  `full_gc_collection_time` bigint(20) DEFAULT NULL,
  `span_young_gc_collection_count` bigint(20) DEFAULT NULL,
  `span_young_gc_collection_time` bigint(20) DEFAULT NULL,
  `span_full_gc_collection_count` bigint(20) DEFAULT NULL,
  `span_full_gc_collection_time` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_identity` (`identity`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=51694 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_admin_jvm_memory`
--

DROP TABLE IF EXISTS `lts_admin_jvm_memory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_admin_jvm_memory` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_created` bigint(20) DEFAULT NULL,
  `identity` varchar(64) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  `node_type` varchar(32) DEFAULT NULL,
  `node_group` varchar(64) DEFAULT NULL,
  `heap_memory_committed` bigint(20) DEFAULT NULL,
  `heap_memory_init` bigint(20) DEFAULT NULL,
  `heap_memory_max` bigint(20) DEFAULT NULL,
  `heap_memory_used` bigint(20) DEFAULT NULL,
  `non_heap_memory_committed` bigint(20) DEFAULT NULL,
  `non_heap_memory_init` bigint(20) DEFAULT NULL,
  `non_heap_memory_max` bigint(20) DEFAULT NULL,
  `non_heap_memory_used` bigint(20) DEFAULT NULL,
  `perm_gen_committed` bigint(20) DEFAULT NULL,
  `perm_gen_init` bigint(20) DEFAULT NULL,
  `perm_gen_max` bigint(20) DEFAULT NULL,
  `perm_gen_used` bigint(20) DEFAULT NULL,
  `old_gen_committed` bigint(20) DEFAULT NULL,
  `old_gen_init` bigint(20) DEFAULT NULL,
  `old_gen_max` bigint(20) DEFAULT NULL,
  `old_gen_used` bigint(20) DEFAULT NULL,
  `eden_space_committed` bigint(20) DEFAULT NULL,
  `eden_space_init` bigint(20) DEFAULT NULL,
  `eden_space_max` bigint(20) DEFAULT NULL,
  `eden_space_used` bigint(20) DEFAULT NULL,
  `survivor_committed` bigint(20) DEFAULT NULL,
  `survivor_init` bigint(20) DEFAULT NULL,
  `survivor_max` bigint(20) DEFAULT NULL,
  `survivor_used` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_identity` (`identity`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=51694 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_admin_jvm_thread`
--

DROP TABLE IF EXISTS `lts_admin_jvm_thread`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_admin_jvm_thread` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_created` bigint(20) DEFAULT NULL,
  `identity` varchar(64) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  `node_type` varchar(32) DEFAULT NULL,
  `node_group` varchar(64) DEFAULT NULL,
  `daemon_thread_count` int(11) DEFAULT NULL,
  `thread_count` int(11) DEFAULT NULL,
  `total_started_thread_count` bigint(20) DEFAULT NULL,
  `dead_locked_thread_count` int(11) DEFAULT NULL,
  `process_cpu_time_rate` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_identity` (`identity`),
  KEY `idx_timestamp` (`timestamp`)
) ENGINE=InnoDB AUTO_INCREMENT=51694 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_admin_node_onoffline_log`
--

DROP TABLE IF EXISTS `lts_admin_node_onoffline_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_admin_node_onoffline_log` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `log_time` timestamp NULL DEFAULT NULL,
  `event` varchar(32) DEFAULT NULL,
  `node_type` varchar(16) DEFAULT NULL,
  `cluster_name` varchar(64) DEFAULT NULL,
  `ip` varchar(16) DEFAULT NULL,
  `port` int(11) DEFAULT NULL,
  `host_name` varchar(64) DEFAULT NULL,
  `group` varchar(64) DEFAULT NULL,
  `create_time` bigint(20) DEFAULT NULL,
  `threads` int(11) DEFAULT NULL,
  `identity` varchar(64) DEFAULT NULL,
  `http_cmd_port` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_log_time` (`log_time`),
  KEY `idx_event` (`event`),
  KEY `idx_identity` (`identity`),
  KEY `idx_group` (`group`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_admin_task_tracker_monitor_data`
--

DROP TABLE IF EXISTS `lts_admin_task_tracker_monitor_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_admin_task_tracker_monitor_data` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_created` bigint(20) DEFAULT NULL,
  `node_group` varchar(64) DEFAULT NULL,
  `identity` varchar(64) DEFAULT NULL,
  `exe_success_num` bigint(20) DEFAULT NULL,
  `exe_failed_num` bigint(11) DEFAULT NULL,
  `exe_later_num` bigint(20) DEFAULT NULL,
  `exe_exception_num` bigint(20) DEFAULT NULL,
  `total_running_time` bigint(20) DEFAULT NULL,
  `timestamp` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_timestamp` (`timestamp`),
  KEY `idx_identity` (`identity`),
  KEY `idx_node_group` (`node_group`)
) ENGINE=InnoDB AUTO_INCREMENT=41349 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_cron_job_queue`
--

DROP TABLE IF EXISTS `lts_cron_job_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_cron_job_queue` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID,??????',
  `job_id` varchar(32) DEFAULT NULL COMMENT '??ID,?????',
  `job_type` varchar(32) DEFAULT NULL COMMENT '????',
  `priority` int(11) DEFAULT NULL COMMENT '???,(????,?????)',
  `retry_times` int(11) DEFAULT '0' COMMENT '????',
  `max_retry_times` int(11) DEFAULT '0' COMMENT '??????',
  `rely_on_prev_cycle` tinyint(4) DEFAULT NULL COMMENT '???????????',
  `task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `real_task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '????',
  `gmt_modified` bigint(11) DEFAULT NULL COMMENT '????',
  `submit_node_group` varchar(64) DEFAULT NULL COMMENT '?????,?????????',
  `task_tracker_node_group` varchar(64) DEFAULT NULL COMMENT '?????,??job?????',
  `ext_params` text COMMENT '???? JSON',
  `internal_ext_params` text COMMENT '?????? JSON',
  `is_running` tinyint(1) DEFAULT NULL COMMENT '??????',
  `task_tracker_identity` varchar(64) DEFAULT NULL COMMENT 'taskTrackerId,???taskTracker?????',
  `need_feedback` tinyint(4) DEFAULT NULL COMMENT '?????,??????????',
  `cron_expression` varchar(128) DEFAULT NULL COMMENT 'Cron???,??????? (? quartz ?????)',
  `trigger_time` bigint(20) DEFAULT NULL COMMENT '???????',
  `repeat_count` int(11) DEFAULT '0' COMMENT '????',
  `repeated_count` int(11) DEFAULT '0' COMMENT '???????',
  `repeat_interval` bigint(20) DEFAULT '0' COMMENT '????',
  `last_generate_trigger_time` bigint(20) DEFAULT '0' COMMENT '?????triggerTime??',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_job_id` (`job_id`),
  UNIQUE KEY `idx_taskId_taskTrackerNodeGroup` (`task_id`,`task_tracker_node_group`),
  KEY `idx_realTaskId_taskTrackerNodeGroup` (`real_task_id`,`task_tracker_node_group`),
  KEY `idx_relyOnPrevCycle_lgtt` (`rely_on_prev_cycle`,`last_generate_trigger_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cron??';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_executing_job_queue`
--

DROP TABLE IF EXISTS `lts_executing_job_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_executing_job_queue` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID,??????',
  `job_id` varchar(32) DEFAULT NULL COMMENT '??ID,?????',
  `job_type` varchar(32) DEFAULT NULL COMMENT '????',
  `priority` int(11) DEFAULT NULL COMMENT '???,(????,?????)',
  `retry_times` int(11) DEFAULT '0' COMMENT '????',
  `max_retry_times` int(11) DEFAULT '0' COMMENT '??????',
  `rely_on_prev_cycle` tinyint(4) DEFAULT NULL COMMENT '???????????',
  `task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `real_task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '????',
  `gmt_modified` bigint(11) DEFAULT NULL COMMENT '????',
  `submit_node_group` varchar(64) DEFAULT NULL COMMENT '?????,?????????',
  `task_tracker_node_group` varchar(64) DEFAULT NULL COMMENT '?????,??job?????',
  `ext_params` text COMMENT '???? JSON',
  `internal_ext_params` text COMMENT '?????? JSON',
  `is_running` tinyint(1) DEFAULT NULL COMMENT '??????',
  `task_tracker_identity` varchar(64) DEFAULT NULL COMMENT 'taskTrackerId,???taskTracker?????',
  `need_feedback` tinyint(4) DEFAULT NULL COMMENT '?????,??????????',
  `cron_expression` varchar(128) DEFAULT NULL COMMENT 'Cron???,??????? (? quartz ?????)',
  `trigger_time` bigint(20) DEFAULT NULL COMMENT '???????',
  `repeat_count` int(11) DEFAULT '0' COMMENT '????',
  `repeated_count` int(11) DEFAULT '0' COMMENT '???????',
  `repeat_interval` bigint(20) DEFAULT '0' COMMENT '????',
  `last_generate_trigger_time` bigint(20) DEFAULT '0' COMMENT '?????triggerTime??',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_job_id` (`job_id`),
  UNIQUE KEY `idx_taskId_taskTrackerNodeGroup` (`task_id`,`task_tracker_node_group`),
  KEY `idx_job_type` (`job_type`),
  KEY `idx_realTaskId_taskTrackerNodeGroup` (`real_task_id`,`task_tracker_node_group`),
  KEY `idx_taskTrackerIdentity` (`task_tracker_identity`),
  KEY `idx_gmtCreated` (`gmt_created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_job_log_po`
--

DROP TABLE IF EXISTS `lts_job_log_po`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_job_log_po` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '??????',
  `log_time` bigint(20) DEFAULT NULL COMMENT '??????',
  `log_type` varchar(32) DEFAULT NULL COMMENT '????',
  `success` tinyint(11) DEFAULT NULL COMMENT '????',
  `msg` text COMMENT '??',
  `code` varchar(32) DEFAULT NULL COMMENT '????',
  `job_type` varchar(32) DEFAULT NULL COMMENT '????',
  `task_tracker_identity` varchar(64) DEFAULT NULL COMMENT '????????',
  `level` varchar(32) DEFAULT NULL COMMENT '??????',
  `task_id` varchar(64) DEFAULT NULL COMMENT '???ID',
  `real_task_id` varchar(64) DEFAULT NULL COMMENT '???ID',
  `job_id` varchar(64) DEFAULT '' COMMENT '?????ID',
  `priority` int(11) DEFAULT NULL COMMENT '???',
  `submit_node_group` varchar(64) DEFAULT NULL COMMENT '?????',
  `task_tracker_node_group` varchar(64) DEFAULT NULL COMMENT '?????',
  `ext_params` text COMMENT '????',
  `internal_ext_params` text COMMENT '?????? JSON',
  `need_feedback` tinyint(4) DEFAULT NULL COMMENT '??????',
  `cron_expression` varchar(128) DEFAULT NULL COMMENT 'cron???',
  `trigger_time` bigint(20) DEFAULT NULL COMMENT '????',
  `retry_times` int(11) DEFAULT NULL COMMENT '????',
  `max_retry_times` int(11) DEFAULT '0' COMMENT '??????',
  `rely_on_prev_cycle` tinyint(4) DEFAULT NULL COMMENT '???????????',
  `repeat_count` int(11) DEFAULT '0' COMMENT '????',
  `repeated_count` int(11) DEFAULT '0' COMMENT '???????',
  `repeat_interval` bigint(20) DEFAULT '0' COMMENT '????',
  PRIMARY KEY (`id`),
  KEY `log_time` (`log_time`),
  KEY `task_id_task_tracker_node_group` (`task_id`,`task_tracker_node_group`),
  KEY `idx_realTaskId_taskTrackerNodeGroup` (`real_task_id`,`task_tracker_node_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_node_group_store`
--

DROP TABLE IF EXISTS `lts_node_group_store`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_node_group_store` (
  `node_type` varchar(16) NOT NULL DEFAULT '' COMMENT '????',
  `name` varchar(64) NOT NULL DEFAULT '' COMMENT '??',
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '????',
  PRIMARY KEY (`node_type`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='???';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_repeat_job_queue`
--

DROP TABLE IF EXISTS `lts_repeat_job_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_repeat_job_queue` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID,??????',
  `job_id` varchar(32) DEFAULT NULL COMMENT '??ID,?????',
  `job_type` varchar(32) DEFAULT NULL COMMENT '????',
  `priority` int(11) DEFAULT NULL COMMENT '???,(????,?????)',
  `retry_times` int(11) DEFAULT '0' COMMENT '????',
  `max_retry_times` int(11) DEFAULT '0' COMMENT '??????',
  `rely_on_prev_cycle` tinyint(4) DEFAULT NULL COMMENT '???????????',
  `task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `real_task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '????',
  `gmt_modified` bigint(11) DEFAULT NULL COMMENT '????',
  `submit_node_group` varchar(64) DEFAULT NULL COMMENT '?????,?????????',
  `task_tracker_node_group` varchar(64) DEFAULT NULL COMMENT '?????,??job?????',
  `ext_params` text COMMENT '???? JSON',
  `internal_ext_params` text COMMENT '?????? JSON',
  `is_running` tinyint(1) DEFAULT NULL COMMENT '??????',
  `task_tracker_identity` varchar(64) DEFAULT NULL COMMENT 'taskTrackerId,???taskTracker?????',
  `need_feedback` tinyint(4) DEFAULT NULL COMMENT '?????,??????????',
  `cron_expression` varchar(128) DEFAULT NULL COMMENT 'Cron???,??????? (? quartz ?????)',
  `trigger_time` bigint(20) DEFAULT NULL COMMENT '???????',
  `repeat_count` int(11) DEFAULT '0' COMMENT '????',
  `repeated_count` int(11) DEFAULT '0' COMMENT '???????',
  `repeat_interval` bigint(20) DEFAULT '0' COMMENT '????',
  `last_generate_trigger_time` bigint(20) DEFAULT '0' COMMENT '?????triggerTime??',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_job_id` (`job_id`),
  UNIQUE KEY `idx_taskId_taskTrackerNodeGroup` (`task_id`,`task_tracker_node_group`),
  KEY `idx_realTaskId_taskTrackerNodeGroup` (`real_task_id`,`task_tracker_node_group`),
  KEY `idx_relyOnPrevCycle_lgtt` (`rely_on_prev_cycle`,`last_generate_trigger_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Repeat??';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_suspend_job_queue`
--

DROP TABLE IF EXISTS `lts_suspend_job_queue`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_suspend_job_queue` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID,??????',
  `job_id` varchar(32) DEFAULT NULL COMMENT '??ID,?????',
  `job_type` varchar(32) DEFAULT NULL COMMENT '????',
  `priority` int(11) DEFAULT NULL COMMENT '???,(????,?????)',
  `retry_times` int(11) DEFAULT '0' COMMENT '????',
  `max_retry_times` int(11) DEFAULT '0' COMMENT '??????',
  `rely_on_prev_cycle` tinyint(4) DEFAULT NULL COMMENT '???????????',
  `task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `real_task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '????',
  `gmt_modified` bigint(11) DEFAULT NULL COMMENT '????',
  `submit_node_group` varchar(64) DEFAULT NULL COMMENT '?????,?????????',
  `task_tracker_node_group` varchar(64) DEFAULT NULL COMMENT '?????,??job?????',
  `ext_params` text COMMENT '???? JSON',
  `internal_ext_params` text COMMENT '?????? JSON',
  `is_running` tinyint(1) DEFAULT NULL COMMENT '??????',
  `task_tracker_identity` varchar(64) DEFAULT NULL COMMENT 'taskTrackerId,???taskTracker?????',
  `need_feedback` tinyint(4) DEFAULT NULL COMMENT '?????,??????????',
  `cron_expression` varchar(128) DEFAULT NULL COMMENT 'Cron???,??????? (? quartz ?????)',
  `trigger_time` bigint(20) DEFAULT NULL COMMENT '???????',
  `repeat_count` int(11) DEFAULT '0' COMMENT '????',
  `repeated_count` int(11) DEFAULT '0' COMMENT '???????',
  `repeat_interval` bigint(20) DEFAULT '0' COMMENT '????',
  `last_generate_trigger_time` bigint(20) DEFAULT '0' COMMENT '?????triggerTime??',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_job_id` (`job_id`),
  UNIQUE KEY `idx_taskId_taskTrackerNodeGroup` (`task_id`,`task_tracker_node_group`),
  KEY `idx_job_type` (`job_type`),
  KEY `idx_realTaskId_taskTrackerNodeGroup` (`real_task_id`,`task_tracker_node_group`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Cron?????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_wjq_henan-common-base`
--

DROP TABLE IF EXISTS `lts_wjq_henan-common-base`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_wjq_henan-common-base` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID,??????',
  `job_id` varchar(32) DEFAULT NULL COMMENT '??ID,?????',
  `job_type` varchar(32) DEFAULT NULL COMMENT '????',
  `priority` int(11) DEFAULT NULL COMMENT '???,(????,?????)',
  `retry_times` int(11) DEFAULT '0' COMMENT '????',
  `max_retry_times` int(11) DEFAULT '0' COMMENT '??????',
  `rely_on_prev_cycle` tinyint(4) DEFAULT NULL COMMENT '???????????',
  `task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `real_task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '????',
  `gmt_modified` bigint(11) DEFAULT NULL COMMENT '????',
  `submit_node_group` varchar(64) DEFAULT NULL COMMENT '?????,?????????',
  `task_tracker_node_group` varchar(64) DEFAULT NULL COMMENT '?????,??job?????',
  `ext_params` text COMMENT '???? JSON',
  `internal_ext_params` text COMMENT '?????? JSON',
  `is_running` tinyint(1) DEFAULT NULL COMMENT '??????',
  `task_tracker_identity` varchar(64) DEFAULT NULL COMMENT 'taskTrackerId,???taskTracker?????',
  `need_feedback` tinyint(4) DEFAULT NULL COMMENT '?????,??????????',
  `cron_expression` varchar(128) DEFAULT NULL COMMENT 'Cron???,??????? (? quartz ?????)',
  `trigger_time` bigint(20) DEFAULT NULL COMMENT '???????',
  `repeat_count` int(11) DEFAULT '0' COMMENT '????',
  `repeated_count` int(11) DEFAULT '0' COMMENT '???????',
  `repeat_interval` bigint(20) DEFAULT '0' COMMENT '????',
  `last_generate_trigger_time` bigint(20) DEFAULT '0' COMMENT '?????triggerTime??',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_job_id` (`job_id`),
  UNIQUE KEY `idx_taskId_taskTrackerNodeGroup` (`task_id`,`task_tracker_node_group`),
  KEY `idx_taskTrackerIdentity` (`task_tracker_identity`),
  KEY `idx_job_type` (`job_type`),
  KEY `idx_realTaskId_taskTrackerNodeGroup` (`real_task_id`,`task_tracker_node_group`),
  KEY `idx_priority_triggerTime_gmtCreated` (`priority`,`trigger_time`,`gmt_created`),
  KEY `idx_isRunning` (`is_running`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='??????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_wjq_henan-common-notice`
--

DROP TABLE IF EXISTS `lts_wjq_henan-common-notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_wjq_henan-common-notice` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID,??????',
  `job_id` varchar(32) DEFAULT NULL COMMENT '??ID,?????',
  `job_type` varchar(32) DEFAULT NULL COMMENT '????',
  `priority` int(11) DEFAULT NULL COMMENT '???,(????,?????)',
  `retry_times` int(11) DEFAULT '0' COMMENT '????',
  `max_retry_times` int(11) DEFAULT '0' COMMENT '??????',
  `rely_on_prev_cycle` tinyint(4) DEFAULT NULL COMMENT '???????????',
  `task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `real_task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '????',
  `gmt_modified` bigint(11) DEFAULT NULL COMMENT '????',
  `submit_node_group` varchar(64) DEFAULT NULL COMMENT '?????,?????????',
  `task_tracker_node_group` varchar(64) DEFAULT NULL COMMENT '?????,??job?????',
  `ext_params` text COMMENT '???? JSON',
  `internal_ext_params` text COMMENT '?????? JSON',
  `is_running` tinyint(1) DEFAULT NULL COMMENT '??????',
  `task_tracker_identity` varchar(64) DEFAULT NULL COMMENT 'taskTrackerId,???taskTracker?????',
  `need_feedback` tinyint(4) DEFAULT NULL COMMENT '?????,??????????',
  `cron_expression` varchar(128) DEFAULT NULL COMMENT 'Cron???,??????? (? quartz ?????)',
  `trigger_time` bigint(20) DEFAULT NULL COMMENT '???????',
  `repeat_count` int(11) DEFAULT '0' COMMENT '????',
  `repeated_count` int(11) DEFAULT '0' COMMENT '???????',
  `repeat_interval` bigint(20) DEFAULT '0' COMMENT '????',
  `last_generate_trigger_time` bigint(20) DEFAULT '0' COMMENT '?????triggerTime??',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_job_id` (`job_id`),
  UNIQUE KEY `idx_taskId_taskTrackerNodeGroup` (`task_id`,`task_tracker_node_group`),
  KEY `idx_taskTrackerIdentity` (`task_tracker_identity`),
  KEY `idx_job_type` (`job_type`),
  KEY `idx_realTaskId_taskTrackerNodeGroup` (`real_task_id`,`task_tracker_node_group`),
  KEY `idx_priority_triggerTime_gmtCreated` (`priority`,`trigger_time`,`gmt_created`),
  KEY `idx_isRunning` (`is_running`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='??????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_wjq_henan-common-notify`
--

DROP TABLE IF EXISTS `lts_wjq_henan-common-notify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_wjq_henan-common-notify` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID,??????',
  `job_id` varchar(32) DEFAULT NULL COMMENT '??ID,?????',
  `job_type` varchar(32) DEFAULT NULL COMMENT '????',
  `priority` int(11) DEFAULT NULL COMMENT '???,(????,?????)',
  `retry_times` int(11) DEFAULT '0' COMMENT '????',
  `max_retry_times` int(11) DEFAULT '0' COMMENT '??????',
  `rely_on_prev_cycle` tinyint(4) DEFAULT NULL COMMENT '???????????',
  `task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `real_task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '????',
  `gmt_modified` bigint(11) DEFAULT NULL COMMENT '????',
  `submit_node_group` varchar(64) DEFAULT NULL COMMENT '?????,?????????',
  `task_tracker_node_group` varchar(64) DEFAULT NULL COMMENT '?????,??job?????',
  `ext_params` text COMMENT '???? JSON',
  `internal_ext_params` text COMMENT '?????? JSON',
  `is_running` tinyint(1) DEFAULT NULL COMMENT '??????',
  `task_tracker_identity` varchar(64) DEFAULT NULL COMMENT 'taskTrackerId,???taskTracker?????',
  `need_feedback` tinyint(4) DEFAULT NULL COMMENT '?????,??????????',
  `cron_expression` varchar(128) DEFAULT NULL COMMENT 'Cron???,??????? (? quartz ?????)',
  `trigger_time` bigint(20) DEFAULT NULL COMMENT '???????',
  `repeat_count` int(11) DEFAULT '0' COMMENT '????',
  `repeated_count` int(11) DEFAULT '0' COMMENT '???????',
  `repeat_interval` bigint(20) DEFAULT '0' COMMENT '????',
  `last_generate_trigger_time` bigint(20) DEFAULT '0' COMMENT '?????triggerTime??',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_job_id` (`job_id`),
  UNIQUE KEY `idx_taskId_taskTrackerNodeGroup` (`task_id`,`task_tracker_node_group`),
  KEY `idx_taskTrackerIdentity` (`task_tracker_identity`),
  KEY `idx_job_type` (`job_type`),
  KEY `idx_realTaskId_taskTrackerNodeGroup` (`real_task_id`,`task_tracker_node_group`),
  KEY `idx_priority_triggerTime_gmtCreated` (`priority`,`trigger_time`,`gmt_created`),
  KEY `idx_isRunning` (`is_running`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='??????';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lts_wjq_henan-common-score`
--

DROP TABLE IF EXISTS `lts_wjq_henan-common-score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lts_wjq_henan-common-score` (
  `id` bigint(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID,??????',
  `job_id` varchar(32) DEFAULT NULL COMMENT '??ID,?????',
  `job_type` varchar(32) DEFAULT NULL COMMENT '????',
  `priority` int(11) DEFAULT NULL COMMENT '???,(????,?????)',
  `retry_times` int(11) DEFAULT '0' COMMENT '????',
  `max_retry_times` int(11) DEFAULT '0' COMMENT '??????',
  `rely_on_prev_cycle` tinyint(4) DEFAULT NULL COMMENT '???????????',
  `task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `real_task_id` varchar(64) DEFAULT NULL COMMENT '??ID,?????????ID',
  `gmt_created` bigint(20) DEFAULT NULL COMMENT '????',
  `gmt_modified` bigint(11) DEFAULT NULL COMMENT '????',
  `submit_node_group` varchar(64) DEFAULT NULL COMMENT '?????,?????????',
  `task_tracker_node_group` varchar(64) DEFAULT NULL COMMENT '?????,??job?????',
  `ext_params` text COMMENT '???? JSON',
  `internal_ext_params` text COMMENT '?????? JSON',
  `is_running` tinyint(1) DEFAULT NULL COMMENT '??????',
  `task_tracker_identity` varchar(64) DEFAULT NULL COMMENT 'taskTrackerId,???taskTracker?????',
  `need_feedback` tinyint(4) DEFAULT NULL COMMENT '?????,??????????',
  `cron_expression` varchar(128) DEFAULT NULL COMMENT 'Cron???,??????? (? quartz ?????)',
  `trigger_time` bigint(20) DEFAULT NULL COMMENT '???????',
  `repeat_count` int(11) DEFAULT '0' COMMENT '????',
  `repeated_count` int(11) DEFAULT '0' COMMENT '???????',
  `repeat_interval` bigint(20) DEFAULT '0' COMMENT '????',
  `last_generate_trigger_time` bigint(20) DEFAULT '0' COMMENT '?????triggerTime??',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_job_id` (`job_id`),
  UNIQUE KEY `idx_taskId_taskTrackerNodeGroup` (`task_id`,`task_tracker_node_group`),
  KEY `idx_taskTrackerIdentity` (`task_tracker_identity`),
  KEY `idx_job_type` (`job_type`),
  KEY `idx_realTaskId_taskTrackerNodeGroup` (`real_task_id`,`task_tracker_node_group`),
  KEY `idx_priority_triggerTime_gmtCreated` (`priority`,`trigger_time`,`gmt_created`),
  KEY `idx_isRunning` (`is_running`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='??????';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-13 14:58:59
