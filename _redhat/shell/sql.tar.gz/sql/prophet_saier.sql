-- MySQL dump 10.13  Distrib 5.7.22, for Linux (x86_64)
--
-- Host: localhost    Database: prophet_saier
-- ------------------------------------------------------
-- Server version	5.7.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `assess_score_config`
--

DROP TABLE IF EXISTS `assess_score_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assess_score_config` (
  `id` varchar(255) NOT NULL,
  `rule` int(11) DEFAULT NULL COMMENT '规则例如多少小时',
  `score_deduct` int(11) DEFAULT NULL COMMENT '扣分数',
  `rule_desc` varchar(255) DEFAULT NULL COMMENT '规则描述例如，根据超时事件数扣分',
  `score_type_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assess_score_type`
--

DROP TABLE IF EXISTS `assess_score_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assess_score_type` (
  `id` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL COMMENT '统计方式',
  `type_desc` varchar(255) DEFAULT NULL COMMENT '描述',
  `type_score` int(11) DEFAULT NULL COMMENT '总分',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assess_third_score`
--

DROP TABLE IF EXISTS `assess_third_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assess_third_score` (
  `id` varchar(255) NOT NULL COMMENT 'id',
  `third_source` varchar(255) DEFAULT NULL COMMENT '第三方来源名称',
  `report_count` int(11) DEFAULT NULL COMMENT '上报个数',
  `assess_time` date DEFAULT NULL COMMENT '统计时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `assess_unit_score`
--

DROP TABLE IF EXISTS `assess_unit_score`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assess_unit_score` (
  `id` varchar(255) NOT NULL,
  `unit_id` varchar(255) NOT NULL COMMENT '单位ID',
  `unit_name` varchar(255) DEFAULT NULL COMMENT '单位名称',
  `unit_score` int(11) DEFAULT NULL COMMENT '考核评分',
  `assess_time` date DEFAULT NULL COMMENT '考核时间统计时间',
  `up_unit_id_1` varchar(255) DEFAULT NULL COMMENT '上级单位',
  `up_unit_id_2` varchar(255) DEFAULT NULL COMMENT '二级单位',
  `up_unit_id_3` varchar(255) DEFAULT NULL COMMENT '三级单位',
  `up_unit_id_4` varchar(255) DEFAULT NULL COMMENT '四级单位',
  `up_unit_id_5` varchar(255) DEFAULT NULL COMMENT '五级单位',
  `over_time_event` longtext COMMENT '超时事件id字符串 多个逗号隔开',
  `over_time_event_count` int(10) DEFAULT NULL COMMENT '超时事件个数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `asset`
--

DROP TABLE IF EXISTS `asset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset` (
  `id` varchar(255) NOT NULL COMMENT 'id',
  `title` varchar(1024) DEFAULT NULL COMMENT '标题',
  `url` varchar(1024) DEFAULT NULL COMMENT '入口url',
  `domain` varchar(512) DEFAULT NULL COMMENT '域名',
  `ip` varchar(255) DEFAULT NULL COMMENT 'ip地址',
  `province` varchar(255) DEFAULT NULL COMMENT '行政省份',
  `city` varchar(255) DEFAULT NULL COMMENT '行政城市',
  `district` varchar(255) DEFAULT NULL COMMENT '行政区县',
  `unit_id` varchar(255) DEFAULT NULL COMMENT '单位Id',
  `up_unit_id_1` varchar(255) DEFAULT NULL COMMENT '上级单位id',
  `up_unit_id_2` varchar(255) DEFAULT NULL COMMENT '上级单位的上级单位id',
  `up_unit_id_3` varchar(255) DEFAULT NULL COMMENT '上级单位的上上级单位id',
  `up_unit_id_4` varchar(255) DEFAULT NULL COMMENT '上级单位的上上上级单位id',
  `up_unit_id_5` varchar(255) DEFAULT NULL COMMENT '上级单位的上上上上级单位id',
  `whois` varchar(1024) DEFAULT NULL COMMENT 'whois信息',
  `icp` varchar(255) DEFAULT NULL COMMENT 'icp信息',
  `level` varchar(255) DEFAULT 'Safe',
  `is_delete` int(3) NOT NULL DEFAULT '0' COMMENT 'is_delete',
  `survey` int(11) DEFAULT '1' COMMENT '服务质量1:正常  -1:请求无响应 -2:资源找不到  -3:服务异常 -4:僵尸站点',
  `point_domain` int(11) DEFAULT '0' COMMENT '是不是重要站点：1:是 0:不是',
  `domain_type` varchar(255) DEFAULT NULL COMMENT '域名类型 如果是ip  填写 ‘ip’',
  `available_status` int(11) DEFAULT '0' COMMENT '是否存活默认存活（0:可以访问,1:不能访问）',
  `create_time` datetime DEFAULT NULL,
  `last_update_time` datetime DEFAULT NULL,
  `is_struts` int(11) DEFAULT '0' COMMENT '是否是struts（0：不是，1：是）',
  PRIMARY KEY (`id`),
  KEY `单位标志` (`unit_id`),
  KEY `上级单位标志` (`up_unit_id_1`),
  KEY `上上级单位标志` (`up_unit_id_2`),
  KEY `上上上级单位标志` (`up_unit_id_3`),
  KEY `上上上上级单位标志` (`up_unit_id_4`),
  KEY `上上上上上级单位标志` (`up_unit_id_5`),
  KEY `威胁等级` (`level`),
  KEY `域名` (`domain`(255)),
  KEY `is_delete_index` (`is_delete`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `asset_site_cms`
--

DROP TABLE IF EXISTS `asset_site_cms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `asset_site_cms` (
  `id` varchar(255) NOT NULL,
  `asset_id` varchar(255) NOT NULL,
  `site_cms_id` varchar(255) NOT NULL,
  `is_delete` int(11) DEFAULT '0' COMMENT '是否删除（1：删除 0：未删除）',
  `manul_flag` int(11) DEFAULT '0' COMMENT '是否修改（1：修改过 0：未修改）',
  PRIMARY KEY (`id`),
  KEY `asset_id_index` (`asset_id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auth_role`
--

DROP TABLE IF EXISTS `auth_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_role` (
  `id` varchar(64) NOT NULL,
  `role_name` varchar(20) NOT NULL,
  `create_user` varchar(64) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `last_modify_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auth_url`
--

DROP TABLE IF EXISTS `auth_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_url` (
  `id` varchar(64) NOT NULL,
  `url` varchar(255) NOT NULL,
  `url_desc` varchar(128) DEFAULT NULL,
  `moudle` varchar(64) DEFAULT NULL,
  `method` varchar(12) DEFAULT NULL,
  `service_id` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` varchar(64) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(64) NOT NULL,
  `email` varchar(64) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `active` tinyint(1) DEFAULT '1',
  `business` int(255) DEFAULT NULL COMMENT '职务 1:安全负责人 2:安全联系人',
  `create_user` varchar(36) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `ext_info` varchar(255) DEFAULT NULL,
  `last_modify_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sync_state` tinyint(4) DEFAULT '0' COMMENT '0:无需同步 1:需要同步',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cms`
--

DROP TABLE IF EXISTS `cms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cms` (
  `id` varchar(255) NOT NULL,
  `company` varchar(255) DEFAULT NULL COMMENT '公司名称',
  `risk_count` int(11) DEFAULT NULL COMMENT '漏洞数量',
  `risk_desc` varchar(255) DEFAULT NULL COMMENT '漏洞描述',
  `software` varchar(255) DEFAULT NULL COMMENT '软件名称',
  `vul_type` varchar(255) DEFAULT NULL COMMENT '漏洞类型  多个以逗号隔开',
  `time` timestamp NULL DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `config`
--

DROP TABLE IF EXISTS `config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `config` (
  `id` varchar(255) NOT NULL,
  `key_name` varchar(255) DEFAULT NULL,
  `key_values` longtext,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event`
--

DROP TABLE IF EXISTS `event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event` (
  `id` varchar(255) NOT NULL COMMENT '事件id',
  `domain_id` varchar(255) DEFAULT NULL,
  `task_type` int(3) NOT NULL COMMENT '大类型 1:漏洞 2:事件 3:后门',
  `type` varchar(255) DEFAULT NULL COMMENT '具体类型',
  `url` text NOT NULL COMMENT '事件url',
  `title` varchar(1024) NOT NULL COMMENT '涉事url标题',
  `series_number` varchar(255) NOT NULL COMMENT '事件序列号',
  `happen_time` datetime NOT NULL COMMENT '发现时间',
  `description` longtext NOT NULL COMMENT '事件描述',
  `repair_desc` longtext COMMENT '修复建议',
  `notify_time` datetime DEFAULT NULL COMMENT '通报时间',
  `status` int(3) NOT NULL DEFAULT '0' COMMENT '事件进度 -1:无需通报 0:待通报 1:处置中 2:处置完成',
  `deal_result` int(3) NOT NULL DEFAULT '0' COMMENT '处置结果 0: 未处理  -2:非本单位资产 -1:误报 1:已处理',
  `audit_status` int(3) NOT NULL DEFAULT '0' COMMENT '审核状态 0: 未处理  1:待初审 2:待终审 3:完成',
  `audit_result` int(3) NOT NULL DEFAULT '0' COMMENT '审核结果 0:待审核 1:审核不通过、2:已修复、3:网站关闭、4:无法访问、5:限制内网访问、6:无法复现 -1 误报',
  `notify_unit_type` varchar(255) DEFAULT NULL,
  `notify_unit_id` varchar(255) DEFAULT NULL COMMENT '通报单位',
  `notify_unit_id_1` varchar(255) DEFAULT NULL,
  `notify_unit_id_2` varchar(255) DEFAULT NULL,
  `notify_unit_id_3` varchar(255) DEFAULT NULL,
  `notify_unit_id_4` varchar(255) DEFAULT NULL,
  `notify_unit_id_5` varchar(255) DEFAULT NULL,
  `source_unit_id` varchar(255) DEFAULT NULL COMMENT '涉事单位id',
  `wait_fix_hour` int(11) DEFAULT NULL COMMENT '待修复超时小时数',
  `fix_hour` int(255) DEFAULT NULL COMMENT '修复耗时',
  `over_time_status` int(11) DEFAULT '0' COMMENT '超时状态 0:未超时 1:已超时',
  `last_update_time` datetime DEFAULT NULL COMMENT '最后一次操作时间',
  `province` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `district` varchar(255) DEFAULT NULL,
  `source_id` varchar(255) DEFAULT NULL COMMENT '事件来源单位id',
  `is_delete` int(11) NOT NULL DEFAULT '0' COMMENT '是否有效 0:有效 1:无效',
  `pull_event` int(11) DEFAULT '0' COMMENT '是否是从其他平台pull下来 0:非pull下来的事件 1:是pull下来的事件',
  `push_status` int(11) DEFAULT '0' COMMENT '推送状态 0:未同步 1:已推送 (只有pull_event为1的情况下才使用)',
  `misreport` int(3) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `域名` (`domain_id`),
  KEY `通报单位` (`notify_unit_id`),
  KEY `发现时间` (`happen_time`),
  KEY `状态` (`status`),
  KEY `处置状态` (`audit_status`),
  KEY `超时状态` (`over_time_status`),
  KEY `最近操作时间` (`last_update_time`),
  KEY `上级单位` (`notify_unit_id_1`),
  KEY `2级单位` (`notify_unit_id_2`),
  KEY `3级单位` (`notify_unit_id_3`),
  KEY `4级单位` (`notify_unit_id_4`),
  KEY `5级单位` (`notify_unit_id_5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_attach`
--

DROP TABLE IF EXISTS `event_attach`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_attach` (
  `id` varchar(255) NOT NULL,
  `event_id` varchar(255) DEFAULT NULL,
  `type` int(255) DEFAULT NULL COMMENT '1:取证截图、2:事件附件、3:处置附件、4:初审附件、5:终审附件 、6:跟踪确认附件',
  `save_path` varchar(255) DEFAULT NULL,
  `file_name` varchar(255) DEFAULT NULL,
  `uploader_id` varchar(255) DEFAULT NULL COMMENT '上传人id',
  `event_log_id` varchar(255) DEFAULT NULL COMMENT '操作记录id',
  `upload_time` datetime DEFAULT NULL COMMENT '上传时间',
  `is_delete` int(3) NOT NULL DEFAULT '0' COMMENT '是否有效 0:有效 1:无效',
  PRIMARY KEY (`id`),
  KEY `事件id` (`event_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_census`
--

DROP TABLE IF EXISTS `event_census`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_census` (
  `id` varchar(255) NOT NULL,
  `date` date NOT NULL COMMENT '统计日期',
  `receive` int(11) DEFAULT '0' COMMENT '从运营中心推送过来的事件数量(当天发现数happen_time)',
  `notify` int(11) DEFAULT '0' COMMENT '通报数(当天通报个数 notify_time=now())',
  `deal` int(11) DEFAULT '0' COMMENT '处置数(当天处置个数 日志表)stage=2',
  `preAudit` int(11) DEFAULT '0' COMMENT '初审数(日志表)stage=3',
  `finAudit` int(11) DEFAULT '0' COMMENT '终审数(日志表operate_time)stage=4',
  `repaired` int(11) DEFAULT '0' COMMENT '修复数(日志表)stage=4 and deal_status=2',
  `timeout` int(11) DEFAULT '0' COMMENT '超时数(send_time=now() and type = 2 msg表)',
  `undeal` int(11) DEFAULT '0' COMMENT '历史积累的未处置数',
  `time` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '统计时间',
  `unit_id` varchar(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='事件每天统计';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_fg`
--

DROP TABLE IF EXISTS `event_fg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_fg` (
  `id` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL COMMENT '标题',
  `url` varchar(255) DEFAULT NULL COMMENT 'url',
  `happen_time` datetime DEFAULT NULL COMMENT '发生时间',
  `province` varchar(255) DEFAULT NULL COMMENT '省',
  `city` varchar(255) DEFAULT NULL COMMENT '市',
  `district` varchar(255) DEFAULT NULL COMMENT '区',
  `happen_year` varchar(255) DEFAULT NULL COMMENT '发生年份',
  `happen_month` varchar(255) DEFAULT NULL COMMENT '发生月份',
  `domain` varchar(255) DEFAULT NULL COMMENT 'domain',
  `snapshot` varchar(255) DEFAULT NULL COMMENT '截图',
  `buss_type` int(11) DEFAULT NULL COMMENT '行业类型 1 教育行业',
  `url_notify_count` int(11) DEFAULT '0' COMMENT 'url 被通报次数',
  `domain_notify_count` int(11) DEFAULT '0' COMMENT '网站被通报次数',
  `unit_notify_count` int(11) DEFAULT '0' COMMENT '单位被通报次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='反共事件';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_log`
--

DROP TABLE IF EXISTS `event_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_log` (
  `id` varchar(255) NOT NULL COMMENT '操作记录id',
  `event_id` varchar(255) NOT NULL COMMENT '关联事件id',
  `stage` int(3) NOT NULL COMMENT '1:通报、2:处置、3:初审 4:终审 5:跟踪审核',
  `deal_status` int(3) NOT NULL COMMENT '处置结果:\r\n通报结果 1:已通报 -1:无需通报\r\n处置结果 -2:非本单位资产 -1:误报 1:已处理 2:事件转发\r\n审核结果 1:审核不通过、2:已修复、3:网站关闭、4:无法访问、5:限制内网访问、6:无法复现\r\n跟踪审核 1:重新通报 2:无法复现 3:已修复',
  `event_desc` longtext COMMENT '操作描述',
  `operate_time` datetime DEFAULT NULL COMMENT '操作时间',
  `operater_id` varchar(255) DEFAULT NULL COMMENT '操作人id',
  `operater_name` varchar(255) DEFAULT NULL COMMENT '操作人名称',
  `operate_unit` varchar(255) DEFAULT NULL COMMENT '操作人所属单位',
  PRIMARY KEY (`id`),
  KEY `事件id` (`event_id`),
  KEY `操作时间` (`operate_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_msg`
--

DROP TABLE IF EXISTS `event_msg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_msg` (
  `id` varchar(255) NOT NULL,
  `event_id` varchar(255) DEFAULT NULL,
  `unit_id` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '1:通报、2:超时、3:催办、4:审核不通过、5:汇总通知',
  `email_list` varchar(1024) DEFAULT NULL COMMENT '[{name:xxx,value:xxx}]',
  `phone_list` varchar(1024) DEFAULT NULL COMMENT '[{name:xxx,value:xxx}]',
  `send_time` datetime DEFAULT NULL,
  `operater_id` varchar(255) DEFAULT NULL COMMENT '发送人id',
  `operater_name` varchar(255) DEFAULT NULL COMMENT '发送人名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_notify_trace`
--

DROP TABLE IF EXISTS `event_notify_trace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_notify_trace` (
  `id` varchar(255) NOT NULL,
  `event_id` varchar(255) DEFAULT NULL,
  `notify_count` int(255) DEFAULT NULL,
  `event_trace_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_trace`
--

DROP TABLE IF EXISTS `event_trace`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_trace` (
  `id` varchar(255) NOT NULL,
  `trace_date` datetime DEFAULT NULL COMMENT '跟踪日期',
  `event_count` int(11) DEFAULT NULL COMMENT '监测总计',
  `event_add` int(11) DEFAULT NULL COMMENT '本次新增',
  `pre_count` int(11) DEFAULT NULL COMMENT '上周结余',
  `un_access_count` int(11) DEFAULT NULL COMMENT '不可访问总数',
  `access_count` int(11) DEFAULT NULL COMMENT '可访问总数',
  `audit_count` int(11) DEFAULT NULL COMMENT '审核总计',
  `fix_count` int(11) DEFAULT NULL COMMENT '修复总计',
  `un_fix_count` int(11) DEFAULT NULL COMMENT '未修复总计',
  `un_recover_count` int(11) DEFAULT NULL COMMENT '无法复现总计',
  `notify_two_count` int(11) DEFAULT NULL,
  `notify_three_count` int(11) DEFAULT NULL,
  `notify_more_count` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `event_trace_detail`
--

DROP TABLE IF EXISTS `event_trace_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `event_trace_detail` (
  `id` varchar(255) NOT NULL,
  `event_trace_id` varchar(255) DEFAULT NULL,
  `event_id` varchar(255) DEFAULT NULL,
  `available` int(11) DEFAULT NULL COMMENT '是否可访问 0:不能访问 1:可以访问',
  `newable` int(11) DEFAULT NULL COMMENT '是否是新增 0:上周遗留 1:本次新增',
  `status` int(255) DEFAULT '0' COMMENT '状态 0:未确认 1:已确认',
  `deal_result` int(11) DEFAULT '0' COMMENT '处置结果 0:未处置 1:已修复 2:无法复现 3:重新通报',
  `check_time` datetime DEFAULT NULL COMMENT '监测时间',
  `audit_time` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `export_task`
--

DROP TABLE IF EXISTS `export_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `export_task` (
  `id` varchar(255) NOT NULL,
  `export_type` int(11) DEFAULT NULL COMMENT '导出文件类型\r\n1:事件检索',
  `export_path` varchar(255) DEFAULT NULL COMMENT '文件存储路径',
  `query_param` varchar(1024) DEFAULT NULL COMMENT '查询参数',
  `progress` varchar(255) DEFAULT NULL COMMENT '导出进度',
  `export_status` int(11) DEFAULT '0' COMMENT '导出状态 -1:导出失败 0:等待导出 1:正在导出 2:导出成功',
  `exporter` varchar(255) DEFAULT NULL COMMENT '操作人',
  `export_name` varchar(255) DEFAULT NULL COMMENT '导出显示文件名',
  `finish_time` datetime DEFAULT NULL COMMENT '生成完成时间',
  `try_count` int(11) DEFAULT '0' COMMENT '尝试执行次数',
  `message` varchar(1024) DEFAULT NULL COMMENT '执行结果 成功or失败',
  `create_time` datetime DEFAULT NULL COMMENT '生成时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `finger_type`
--

DROP TABLE IF EXISTS `finger_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `finger_type` (
  `id` varchar(60) NOT NULL,
  `ptype` varchar(255) DEFAULT NULL,
  `desc` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `import_task`
--

DROP TABLE IF EXISTS `import_task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `import_task` (
  `id` varchar(255) NOT NULL,
  `import_path` varchar(255) DEFAULT NULL COMMENT '上传文件存放地址',
  `import_name` varchar(255) DEFAULT NULL COMMENT '上传文件源文件名',
  `import_type` int(11) DEFAULT NULL,
  `progress` varchar(255) DEFAULT NULL COMMENT '导入进度',
  `import_status` int(11) DEFAULT '0' COMMENT '导入状态 0 待执行 1执行中 2成功 -1 失败',
  `finish_time` datetime DEFAULT NULL COMMENT '执行时间  ',
  `create_time` datetime DEFAULT NULL,
  `importer` varchar(255) DEFAULT NULL COMMENT '操作人',
  `message` varchar(255) DEFAULT NULL COMMENT '执行结果',
  `try_count` int(11) DEFAULT '0' COMMENT '执行次数',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu` (
  `id` varchar(64) NOT NULL,
  `name` varchar(20) NOT NULL COMMENT '名称',
  `path` varchar(255) DEFAULT NULL COMMENT '路径',
  `icon` varchar(255) DEFAULT NULL COMMENT '图标',
  `is_menu` varchar(255) NOT NULL COMMENT '是否目录',
  `seq` int(11) NOT NULL COMMENT '排序 从小到大排序',
  `is_show` tinyint(4) NOT NULL DEFAULT '1' COMMENT '是否显示 1:显示 0:不显示',
  `pid` varchar(128) DEFAULT NULL COMMENT '父id',
  `blank` int(1) DEFAULT '0' COMMENT '是否在新标签页中打开 1是 0否 默认否',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `menu_url`
--

DROP TABLE IF EXISTS `menu_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `menu_url` (
  `menu_id` varchar(255) NOT NULL,
  `url_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `report_source`
--

DROP TABLE IF EXISTS `report_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_source` (
  `id` varchar(255) NOT NULL COMMENT 'id',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `unit_id` varchar(255) DEFAULT NULL COMMENT '单位id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_menu`
--

DROP TABLE IF EXISTS `role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_menu` (
  `role_id` varchar(255) NOT NULL,
  `menu_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `role_url`
--

DROP TABLE IF EXISTS `role_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_url` (
  `role_id` varchar(64) NOT NULL,
  `url_id` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `safety_info`
--

DROP TABLE IF EXISTS `safety_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `safety_info` (
  `id` varchar(255) NOT NULL,
  `create_time` datetime DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `safety_type_id` varchar(11) DEFAULT NULL,
  `safety_source` varchar(255) DEFAULT NULL,
  `content` longtext COMMENT '安全资讯',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `safety_type`
--

DROP TABLE IF EXISTS `safety_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `safety_type` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `site_cms`
--

DROP TABLE IF EXISTS `site_cms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_cms` (
  `id` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL COMMENT '指纹类型(Apache2.2.32)',
  `big_type` varchar(255) DEFAULT NULL COMMENT '指纹大类型(Apache)',
  `categories_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `site_cms_application`
--

DROP TABLE IF EXISTS `site_cms_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_cms_application` (
  `id` varchar(255) NOT NULL,
  `type` varchar(255) DEFAULT NULL COMMENT '应用类型',
  `name` varchar(255) DEFAULT NULL COMMENT '应用名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `site_cms_categories`
--

DROP TABLE IF EXISTS `site_cms_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_cms_categories` (
  `id` varchar(255) NOT NULL,
  `categories` varchar(100) DEFAULT NULL COMMENT '小类类别',
  `cms_application_id` varchar(255) DEFAULT NULL COMMENT '大类ID',
  `name` varchar(100) DEFAULT NULL COMMENT '小类名称',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `superior_mapper`
--

DROP TABLE IF EXISTS `superior_mapper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `superior_mapper` (
  `id` varchar(255) NOT NULL COMMENT '上级类型id',
  `name` varchar(255) DEFAULT NULL COMMENT '上级类型名称',
  `desc` varchar(255) DEFAULT NULL COMMENT '描述',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task` (
  `id` varchar(64) NOT NULL,
  `sync` int(11) DEFAULT NULL COMMENT '0:单次 1:周期',
  `name` varchar(64) DEFAULT NULL COMMENT '任务名称',
  `type` int(11) DEFAULT NULL COMMENT '1:漏扫 2:暗链 3:基础引擎',
  `interval_hour` int(11) DEFAULT NULL COMMENT '两次任务间隔的小时数',
  `wait_hour` int(11) DEFAULT NULL COMMENT '距离下次开始检测时间',
  `task_status` int(11) DEFAULT NULL COMMENT '0:等待执行 1:执行中 2:任务完成 -1:任务暂停',
  `creater` varchar(64) DEFAULT NULL COMMENT '创建人',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `updater` varchar(64) DEFAULT NULL COMMENT '更新人员',
  `update_time` datetime DEFAULT NULL COMMENT '更新时间',
  `start_time` datetime DEFAULT NULL COMMENT '任务开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '任务完成时间',
  `policy` text COMMENT '扫描策略信息',
  `deep` int(11) DEFAULT NULL COMMENT '爬行深度',
  `mission_type` int(11) DEFAULT '0' COMMENT '0:下发时 直接下发原始数据 1:下发时从新从数据库中查询',
  `mission_time` datetime DEFAULT NULL COMMENT '任务下发时间',
  `task_source_from` int(11) DEFAULT NULL COMMENT '任务类型来源 1:页面提交 2:根据单位选择 3:根据单位类型选择 4:某单位及其下级所有单位 5:系统所有站点',
  `url_init_status` int(11) DEFAULT NULL COMMENT '0:未初始化 1:初始化完成',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task_engine`
--

DROP TABLE IF EXISTS `task_engine`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_engine` (
  `id` varchar(64) NOT NULL,
  `task_id` varchar(64) DEFAULT NULL,
  `engine_task_id` varchar(64) DEFAULT NULL,
  `task_status` int(11) DEFAULT NULL COMMENT '0:等待执行 1:执行中 2:任务完成 -1:任务暂停',
  `start_time` datetime DEFAULT NULL COMMENT '任务开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '任务结束时间',
  `task_mission_id` varchar(64) DEFAULT NULL COMMENT '任务批次',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task_mission`
--

DROP TABLE IF EXISTS `task_mission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_mission` (
  `id` varchar(64) DEFAULT NULL COMMENT '任务下发记录id',
  `task_id` varchar(64) DEFAULT NULL,
  `mission_time` datetime DEFAULT NULL COMMENT '下发时间',
  `url_count` int(11) DEFAULT NULL COMMENT '本次检查url总数',
  `older` int(255) DEFAULT NULL COMMENT '0:正在用的 1:历史任务',
  `mission_status` int(11) DEFAULT NULL COMMENT '0:未下发 1:等待下发 2:已下发'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task_mission_url`
--

DROP TABLE IF EXISTS `task_mission_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_mission_url` (
  `id` varchar(64) DEFAULT NULL,
  `mission_id` varchar(64) DEFAULT NULL,
  `url` varchar(1024) DEFAULT NULL,
  `type` int(11) DEFAULT NULL COMMENT '-1:减 1:加'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task_unit`
--

DROP TABLE IF EXISTS `task_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_unit` (
  `id` varchar(64) NOT NULL COMMENT '任务id',
  `unit_id` varchar(64) DEFAULT NULL COMMENT '单位id',
  `task_id` varchar(64) DEFAULT NULL COMMENT '任务id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task_unit_type`
--

DROP TABLE IF EXISTS `task_unit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_unit_type` (
  `id` varchar(64) NOT NULL,
  `task_id` varchar(64) DEFAULT NULL COMMENT '任务id',
  `unit_type_id` varchar(64) DEFAULT NULL COMMENT '单位类型id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `task_url`
--

DROP TABLE IF EXISTS `task_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `task_url` (
  `id` varchar(64) DEFAULT NULL COMMENT '任务id',
  `url` varchar(1024) DEFAULT NULL COMMENT 'url地址',
  `task_id` varchar(64) DEFAULT NULL COMMENT '对应任务id',
  `engine_task_id` varchar(64) DEFAULT NULL COMMENT '引擎任务id',
  `task_status` int(255) DEFAULT NULL COMMENT '0:等待执行 1:执行中 2:任务完成 -1:任务暂停',
  `start_time` datetime DEFAULT NULL COMMENT '任务开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '任务结束时间',
  `asset_id` varchar(64) DEFAULT NULL COMMENT '对应资产id'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_report_unit`
--

DROP TABLE IF EXISTS `third_report_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_report_unit` (
  `id` varchar(60) NOT NULL COMMENT 'id',
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `type` tinyint(4) DEFAULT NULL COMMENT '类型 1:安全厂商 2:单位',
  `shout` varchar(255) DEFAULT NULL COMMENT '缩写',
  `unit_id` varchar(60) DEFAULT NULL COMMENT '单位id',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `third_threaten`
--

DROP TABLE IF EXISTS `third_threaten`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `third_threaten` (
  `id` varchar(80) NOT NULL COMMENT 'id',
  `type` varchar(255) DEFAULT NULL COMMENT '具体类型',
  `type_name` varchar(255) DEFAULT NULL COMMENT '类型名称',
  `happen_time` datetime DEFAULT NULL COMMENT '发现时间',
  `threaten_desc` longtext COMMENT '威胁描述',
  `effect` longtext COMMENT '受影响的ip清单',
  `suggest` longtext COMMENT '整改建议',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `threaten_mapper`
--

DROP TABLE IF EXISTS `threaten_mapper`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `threaten_mapper` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `type_desc` varchar(1024) DEFAULT NULL,
  `repair_desc` varchar(1024) DEFAULT NULL,
  `type` varchar(255) DEFAULT NULL COMMENT '1:漏洞 2:事件',
  `treaten_pid` varchar(255) DEFAULT NULL COMMENT '二级分类类型',
  `level` varchar(100) DEFAULT NULL COMMENT '威胁严重等级 Critical High Medium Low Info',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unit` (
  `id` varchar(255) NOT NULL COMMENT '单位id',
  `name` varchar(255) DEFAULT NULL COMMENT '单位名称',
  `unit_type_id` varchar(11) DEFAULT NULL COMMENT '单位类型',
  `unit_code` varchar(255) DEFAULT NULL COMMENT '单位编号',
  `pid` varchar(255) DEFAULT NULL COMMENT '上级单位id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `unit_sort` int(255) DEFAULT NULL COMMENT '排序',
  `updater_id` varchar(0) DEFAULT NULL COMMENT '更新人员id',
  `last_update_time` datetime DEFAULT NULL COMMENT '最后更新时间',
  `is_delete` int(255) NOT NULL DEFAULT '0' COMMENT '是否有效 0:有效 1:无效',
  `is_show` int(11) DEFAULT '0' COMMENT '0:显示，1：不显示',
  `province` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `district` varchar(50) DEFAULT NULL,
  `up_unit_id_1` varchar(255) DEFAULT NULL,
  `up_unit_id_2` varchar(255) DEFAULT NULL,
  `up_unit_id_3` varchar(255) DEFAULT NULL,
  `up_unit_id_4` varchar(255) DEFAULT NULL,
  `up_unit_id_5` varchar(255) DEFAULT NULL,
  `region_num` varchar(255) DEFAULT NULL COMMENT '分配给下面的id',
  `send_notify` int(11) DEFAULT '0' COMMENT '是否要给直属下级单位发送汇总消息通知(1:是，0：否)',
  `up_unit_all` varchar(500) DEFAULT NULL,
  `map_tag` int(11) DEFAULT '1' COMMENT '该单位首页是否展示成地图 1 地图  其他列表',
  PRIMARY KEY (`id`),
  KEY `上级单位id` (`pid`),
  KEY `2级单位id` (`up_unit_id_1`),
  KEY `3级单位id` (`up_unit_id_2`),
  KEY `4级单位id` (`up_unit_id_3`),
  KEY `5级单位id` (`up_unit_id_4`),
  KEY `6级单位id` (`up_unit_id_5`),
  KEY `排序` (`unit_sort`) USING BTREE,
  KEY `名称索引` (`name`) USING BTREE,
  KEY `是否显示` (`is_show`),
  KEY `单位类型` (`unit_type_id`) USING BTREE,
  KEY `是否发送单位` (`send_notify`),
  KEY `is_delete_index` (`is_delete`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `unit_type`
--

DROP TABLE IF EXISTS `unit_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unit_type` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `name_desc` varchar(255) DEFAULT NULL COMMENT '描述',
  `is_delete` int(11) DEFAULT '0' COMMENT '是否有效 0:有效 1:无效',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `role_id` varchar(64) NOT NULL,
  `user_id` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_thread_report_unit`
--

DROP TABLE IF EXISTS `user_thread_report_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_thread_report_unit` (
  `user_id` varchar(60) NOT NULL,
  `third_report_unit_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_unit`
--

DROP TABLE IF EXISTS `user_unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_unit` (
  `user_id` varchar(255) NOT NULL,
  `unit_id` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warning`
--

DROP TABLE IF EXISTS `warning`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warning` (
  `id` varchar(36) NOT NULL,
  `title` varchar(500) DEFAULT NULL COMMENT '预警标题',
  `creater` varchar(36) DEFAULT NULL COMMENT '创建人',
  `is_delete` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除 1删除 0 未删除',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `happen_time` datetime DEFAULT NULL COMMENT '预警发生时间',
  `description` longtext COMMENT '预警内容',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warning_cms`
--

DROP TABLE IF EXISTS `warning_cms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warning_cms` (
  `id` varchar(36) DEFAULT NULL,
  `warning_id` varchar(36) DEFAULT NULL,
  `site_cms_id` varchar(36) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warning_log`
--

DROP TABLE IF EXISTS `warning_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warning_log` (
  `id` varchar(36) DEFAULT NULL,
  `warning_id` varchar(36) DEFAULT NULL COMMENT '预警id',
  `warning_scan_id` varchar(36) DEFAULT NULL,
  `operator` varchar(36) DEFAULT NULL COMMENT '操作人',
  `status` int(11) DEFAULT NULL COMMENT '0未发送 1发送中 2 发送成功 3 发送失败',
  `time` datetime DEFAULT NULL COMMENT '发送时间',
  `notice_type` varchar(255) DEFAULT NULL COMMENT '通知类型 1微信 2 邮件 3 短信  多个以逗号分隔',
  `notice_content` longtext COMMENT '通知内容 ',
  `param` longtext COMMENT '参数字符串'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warning_notice_detail`
--

DROP TABLE IF EXISTS `warning_notice_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warning_notice_detail` (
  `id` varchar(36) NOT NULL,
  `unit_id` varchar(36) DEFAULT NULL COMMENT '单位id',
  `warning_id` varchar(36) DEFAULT NULL,
  `site_count` int(10) DEFAULT NULL,
  `unit_count` int(10) DEFAULT NULL,
  `asset_id` varchar(36) DEFAULT NULL,
  `type` int(1) DEFAULT '1' COMMENT '类型 1 部属（单个） 2 省属（聚合）',
  `send_status` int(1) DEFAULT '0' COMMENT '0 未发送  1发送成功 2发送失败',
  `warning_log_id` varchar(36) DEFAULT NULL COMMENT '发送时间',
  `is_delete` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除 1删除 0 未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warning_scan`
--

DROP TABLE IF EXISTS `warning_scan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warning_scan` (
  `id` varchar(36) NOT NULL,
  `warning_id` varchar(36) DEFAULT NULL COMMENT '预警id',
  `scan_time` datetime DEFAULT NULL COMMENT '扫描时间',
  `status` int(11) DEFAULT NULL COMMENT '扫描状态 0未开始 1进行中 2 已完成 3 出错 4更新发送信息中 5更新发送信息完成 6更新发送信息失败',
  `operator` varchar(36) DEFAULT NULL COMMENT '扫描人',
  `scan_count` int(11) DEFAULT NULL COMMENT '扫描结果个数',
  `is_delete` int(3) NOT NULL DEFAULT '0' COMMENT '是否删除 1删除 0 未删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `warning_scan_result`
--

DROP TABLE IF EXISTS `warning_scan_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warning_scan_result` (
  `id` varchar(36) NOT NULL,
  `warning_scan_id` varchar(36) DEFAULT NULL COMMENT '扫描记录id',
  `asset_id` varchar(36) DEFAULT NULL COMMENT '站点id',
  `site_cms_id` varchar(255) DEFAULT NULL COMMENT '匹配到的指纹id 多个逗号隔开',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-06-13 15:01:20
